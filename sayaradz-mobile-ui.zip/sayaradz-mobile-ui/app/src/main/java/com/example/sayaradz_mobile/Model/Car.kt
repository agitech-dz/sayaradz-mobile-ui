package com.example.sayaradz_mobile.Model

data class Car(var carName:String, var carPrice:String, var carImage:String)