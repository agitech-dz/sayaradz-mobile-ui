package com.example.sayaradz_mobile.Model

data class Brand(var brandName:String)