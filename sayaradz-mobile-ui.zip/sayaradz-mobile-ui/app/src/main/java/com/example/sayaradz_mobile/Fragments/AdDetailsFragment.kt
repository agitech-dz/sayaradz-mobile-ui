package com.example.sayaradz_mobile.Fragments

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import com.example.sayaradz_mobile.Adapters.UsedCarAdapter
import com.example.sayaradz_mobile.Model.Car

import com.example.sayaradz_mobile.R
import com.ouattararomuald.slider.ImageSlider
import com.ouattararomuald.slider.SliderAdapter
import com.ouattararomuald.slider.loaders.picasso.PicassoImageLoaderFactory
import java.security.AccessController.getContext

class AdDetailsFragment : Fragment {
    companion object {
        val instance = AdDetailsFragment()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_ad_details, container, false)
        val imageUrls = arrayListOf(
            "https://imgd.aeplcdn.com/424x424/cw/ec/26916/Audi-Q3-Front-view-92293.jpg?v=201711021421&q=85",
            "https://imgd.aeplcdn.com/424x424/cw/ec/26916/Audi-Q3-Front-view-92293.jpg?v=201711021421&q=85",
            "https://imgd.aeplcdn.com/424x424/cw/ec/26916/Audi-Q3-Front-view-92293.jpg?v=201711021421&q=85"
        )


        val imageSlider = container?.findViewById<ImageSlider>(R.id.image_slider)
        imageSlider?.adapter = SliderAdapter(
            container!!.context,
            PicassoImageLoaderFactory(),
            imageUrls = imageUrls
            )
        return view
    }

    //ManufacturerRecycleView--------------------------------------------
    private fun setUpAdSliser(rootView: View) {



    }

}
